package com.company;

public class ExecuteAttack implements Strategy{
    @Override
    public String execute(PokemonInstance pokemon) {
        if(pokemon.getNormalAttack() != 0){
            return "NormalAttack " + pokemon.getNormalAttack();
        } else {
            return "SpecialAttack " + pokemon.getSpecialAttack();
        }
    }
}
