package com.company;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertAll;

public class UnitaryTests {
    public PokemonInstance createInstanceWithSpecialAttack(String name, int HP, int normalDefense, int specialDefense, int attack){
        return new Pokemon.PokemonBuilder(name, HP, normalDefense, specialDefense).withSpecialAttack(attack).build();
    }

    public PokemonInstance createInstanceWithNormalAttack(String name, int HP, int normalDefense, int specialDefense, int attack){
        return new Pokemon.PokemonBuilder(name, HP, normalDefense, specialDefense).withNormalAttack(attack).build();
    }

    @Test
    public void testGetFinalWinner(){
        PokemonInstance p1 = createInstanceWithSpecialAttack("Pikachu", 70, 23, 12, 50);
        PokemonInstance p2 = createInstanceWithSpecialAttack("Bulbasaur", 20, 11, 10, 4);
        PokemonInstance p3 = createInstanceWithSpecialAttack("Vulpix", 70, 23, 12, 50);
        PokemonInstance p = null;
        assertAll(() -> assertEquals("Pikachu", Administration.getFinalWinner(p1, p2, p, p1, p2).getName()),
                () -> assertEquals("Pikachu", Administration.getFinalWinner(p1, p3, p, p1, p3).getName()));
    }

    @Test
    public void testGetFinalWinnerComplex(){
        PokemonInstance p1 = createInstanceWithSpecialAttack("Bulbasaur", 70, 23, 12, 50);
        PokemonInstance p2 = createInstanceWithSpecialAttack("Vulpix", 20, 11, 10, 4);
        PokemonInstance p3 = createInstanceWithSpecialAttack("Bul", 70, 23, 12, 50);
        PokemonInstance p = null;
        assertAll(() -> assertEquals("Bulbasaur", Administration.getFinalWinner(p1, p2, p, p1, p2).getName()),
                () -> assertEquals("Bul", Administration.getFinalWinner(p1, p3, p, p1, p3).getName()));
    }

    @Test
    public void testGetPowersFromMagicalItems(){
        PokemonInstance p = createInstanceWithSpecialAttack("Pikachu", 35, 2, 3, 4);
        PokemonInstance p_expected = createInstanceWithSpecialAttack("Pikachu", 37, 8, 11, 4);
        List<Item> list = new ArrayList<>();
        list.add(new Item("scut", 0, 0, 0, 2, 2));
        list.add(new Item("vitamine", 2, 2, 2, 0, 0));
        list.add(new Item("No Item", 0, 0, 0, 0, 0));
        p.listOfItems = list;
        assertAll(() -> assertEquals(p_expected.getHP(), Administration.getPowersFromMagicalItems(p).getHP()),
                () -> assertEquals(p_expected.getSpecialAttack(), Administration.getPowersFromMagicalItems(p).getNormalAttack()),
                () -> assertEquals(p_expected.getDefense(), Administration.getPowersFromMagicalItems(p).getDefense()),
                () -> assertEquals(p_expected.getSpecialDefense(), Administration.getPowersFromMagicalItems(p).getSpecialDefense()));
    }

    @Test
    public void testGetPowersFromMagicalItemsComplex(){
        PokemonInstance p = createInstanceWithSpecialAttack("Pikachu", 35, 2, 3, 4);
        PokemonInstance p_expected = createInstanceWithSpecialAttack("Pikachu", 35, 8, 11, 0);
        List<Item> list = new ArrayList<>();
        list.add(new Item("scut", 0, 0, 0, 2, 2));
        list.add(new Item("No Item", 0, 0, 0, 0, 0));
        list.add(new Item("No Item", 0, 0, 0, 0, 0));
        p.listOfItems = list;
        assertAll(() -> assertEquals(p_expected.getHP(), Administration.getPowersFromMagicalItems(p).getHP()),
                () -> assertEquals(p_expected.getSpecialAttack(), Administration.getPowersFromMagicalItems(p).getNormalAttack()),
                () -> assertEquals(p_expected.getDefense(), Administration.getPowersFromMagicalItems(p).getDefense()),
                () -> assertEquals(p_expected.getSpecialDefense(), Administration.getPowersFromMagicalItems(p).getSpecialDefense()));
    }

    @Test
    public void testExecuteAbility1(){
        PokemonInstance p1 = createInstanceWithSpecialAttack("Pikachu", 70, 23, 12, 50);
        Ability[] list = new Ability[2];
        list[0] = new Ability("Pikachu", 21, true, false, 4);
        list[1] = new Ability("Pikachu", 11, false, false, 6);
        p1.abilities = list;
        assertEquals("Ability1 Damage 21 Stuned yes Dodge no Cooldown 4", new ExecuteAbility1().execute(p1));
    }

    @Test
    public void testExecuteAbility1Complex(){
        PokemonInstance p1 = createInstanceWithSpecialAttack("Pikachu", 70, 23, 12, 50);
        Ability[] list = new Ability[2];
        list[0] = new Ability("Pikachu", 0, true, true, 5);
        list[1] = new Ability("Pikachu", 11, false, false, 6);
        p1.abilities = list;
        assertEquals("Ability1 null Stuned yes Dodge yes Cooldown 5", new ExecuteAbility1().execute(p1));
    }

    @Test
    public void testExecuteAbility2(){
        PokemonInstance p1 = createInstanceWithSpecialAttack("Pikachu", 70, 23, 12, 50);
        Ability[] list = new Ability[2];
        list[0] = new Ability("Pikachu", 21, true, false, 4);
        list[1] = new Ability("Pikachu", 11, false, false, 6);
        p1.abilities = list;
        assertEquals("Ability2 Damage 11 Stuned no Dodge no Cooldown 6", new ExecuteAbility2().execute(p1));
    }

    @Test
    public void testExecuteAbility2Complex(){
        PokemonInstance p1 = createInstanceWithSpecialAttack("Pikachu", 70, 23, 12, 50);
        Ability[] list = new Ability[2];
        list[0] = new Ability("Pikachu", 21, true, false, 4);
        list[1] = new Ability("Pikachu", 0, false, false, 6);
        p1.abilities = list;
        assertEquals("Ability2 null Stuned no Dodge no Cooldown 6", new ExecuteAbility2().execute(p1));
    }

    @Test
    public void testExecuteSpecialAttack(){
        PokemonInstance p1 = createInstanceWithSpecialAttack("Pikachu", 70, 23, 12, 50);
        assertEquals("SpecialAttack 50", new ExecuteAttack().execute(p1));
    }

    @Test
    public void testExecuteNormalAttack(){
        PokemonInstance p1 = createInstanceWithNormalAttack("Pikachu", 70, 23, 12, 50);
        assertEquals("NormalAttack 50", new ExecuteAttack().execute(p1));
    }

}
