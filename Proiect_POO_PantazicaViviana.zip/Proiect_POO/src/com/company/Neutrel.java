package com.company;

public class Neutrel extends PokemonInstance{
    private String name;                                //required
    private int HP;                                     //required
    private int normalAttack;                           //required
    private int defense;                                //required
    private int specialDefense;                         //required

    public Neutrel(String name, int HP, int normalAttack, int defense, int specialDefense) {
        this.name = name;
        this.HP = HP;
        this.normalAttack = normalAttack;
        this.defense = defense;
        this.specialDefense = specialDefense;
    }

    public String getName() {
        return name;
    }

    public int getHP() {
        return HP;
    }

    public int getNormalAttack() {
        return normalAttack;
    }

    public int getDefense() {
        return defense;
    }

    public int getSpecialDefense() {
        return specialDefense;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setHP(int HP) {
        this.HP = HP;
    }

    public void setNormalAttack(int normalAttack) {
        this.normalAttack = normalAttack;
    }

    public void setDefense(int defense) {
        this.defense = defense;
    }

    public void setSpecialDefense(int specialDefense) {
        this.specialDefense = specialDefense;
    }

    @Override
    public String toString() {
        return null;
    }
}
