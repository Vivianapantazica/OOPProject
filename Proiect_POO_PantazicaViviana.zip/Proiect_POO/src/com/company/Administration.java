package com.company;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

public class Administration {

    public List<Ability> initAbility1(String fileName1){
        List<Ability> abilities1 = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(fileName1))) {
            String line;
            br.readLine();
            while ((line = br.readLine()) != null) {
                String[] values = new String[6];
                int i = 0;
                for (String val : line.split("###")) {
                    values[i] = val;
                    i++;
                }
                boolean booleanType = false;
                if("Yes".equals(values[3])){
                    booleanType = true;
                }
                boolean booleanType1 = false;
                if("Yes".equals(values[2])){
                    booleanType1 = true;
                }
                abilities1.add(new Ability(values[0], Integer.parseInt(values[1]), booleanType1,
                        booleanType, Integer.parseInt(values[4])));
            }
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        return abilities1;
    }

    public List<Ability> initAbility2(String fileName2){
        List<Ability> abilities2 = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(fileName2))) {
            String line;
            br.readLine();
            while ((line = br.readLine()) != null) {
                String[] values = new String[6];
                int i = 0;
                for (String val : line.split("###")) {
                    values[i] = val;
                    i++;
                }
                boolean booleanType = false;
                if("Yes".equals(values[3])){
                    booleanType = true;
                }
                boolean booleanType1 = false;
                if("Yes".equals(values[2])){
                    booleanType1 = true;
                }
                abilities2.add(new Ability(values[0], Integer.parseInt(values[1]), booleanType1,
                        booleanType, Integer.parseInt(values[4])));
            }
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        return abilities2;
    }

    public void initPokemonsWithBothAbilities(List<PokemonInstance> pokemons, List<Ability> abilities1, List<Ability> abilities2){
        for(PokemonInstance pokemon : pokemons){
            for(Ability ab1 : abilities1){
                for(Ability ab2 : abilities2){
                    if(pokemon.getName().equals(ab1.pokemonsName) && pokemon.getName().equals(ab2.pokemonsName)){
                        pokemon.abilities[0] = ab1;
                        pokemon.abilities[1] = ab2;
                    }
                }
            }
        }
    }

    public List<Item> createListOfItems(String fileName) {
        List<Item> items = new ArrayList<>();;
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            br.readLine();
            while ((line = br.readLine()) != null) {
                String[] values = new String[6];
                int i = 0;
                for (String val : line.split("###")) {
                    values[i] = val;
                    i++;
                }
                items.add(new Item(values[0], Integer.parseInt(values[1]), Integer.parseInt(values[2]),
                        Integer.parseInt(values[3]), Integer.parseInt(values[4]), Integer.parseInt(values[5])));
            }
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        return items;
    }

    public List<Coach> initCoaches(String fileName, List<PokemonInstance> pokemons, List<Item> listOfItems){
        List<Coach> coaches = new ArrayList<>();;
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            br.readLine();
            while ((line = br.readLine()) != null) {
                String[] values = new String[14];
                int i = 0;
                for (String val : line.split("###")) {
                    values[i] = val;
                    i++;
                }
                List<PokemonInstance> pokemonList = pokemons.stream().filter(pokemon -> pokemon.getName().equals(values[2]) ||
                                                                                pokemon.getName().equals(values[6]) ||
                                                                                pokemon.getName().equals(values[10]))
                                                                                .collect(Collectors.toList());
                pokemonList.get(0).listOfItems = getListOfItemsForEachPokemon(listOfItems, values, 3);
                pokemonList.get(1).listOfItems = getListOfItemsForEachPokemon(listOfItems, values, 7);
                pokemonList.get(2).listOfItems = getListOfItemsForEachPokemon(listOfItems, values, 11);
                coaches.add(new Coach(pokemonList, Integer.parseInt(values[1]), values[0]));
            }
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        return coaches;
    }

    public List<Item> getListOfItemsForEachPokemon(List<Item> listOfItems, String[] values, int index){
        List<Item> itemsList  = listOfItems.stream().filter(item -> item.name.equals(values[index]) ||
                                                 item.name.equals(values[index+1]) ||
                                                 item.name.equals(values[index+2])).collect(Collectors.toList());

        if(values[index].equals("0")){
            itemsList.add(new Item("No Item", 0, 0, 0, 0, 0));
        }
        if(values[index+1].equals("0")){
            itemsList.add(new Item("No Item", 0, 0, 0, 0, 0));
        }
        if(values[index+2].equals("0")){
            itemsList.add(new Item("No Item", 0, 0, 0, 0, 0));
        }
        return itemsList;
    }

    public static PokemonInstance getPowersFromMagicalItems(PokemonInstance pokemon){
        PokemonInstance poki = pokemon;
        poki.setHP(poki.getHP() + poki.listOfItems.get(0).HP + poki.listOfItems.get(1).HP + poki.listOfItems.get(2).HP);
        poki.setDefense(poki.getDefense() + poki.listOfItems.get(0).defense + poki.listOfItems.get(1).defense + poki.listOfItems.get(2).defense);
        poki.setSpecialDefense(poki.getSpecialDefense() + poki.listOfItems.get(0).specialDefense + poki.listOfItems.get(1).specialDefense
                                + poki.listOfItems.get(2).specialDefense);
        poki.setNormalAttack(poki.getNormalAttack() + poki.listOfItems.get(0).normalAttack + poki.listOfItems.get(1).normalAttack
                                + poki.listOfItems.get(2).normalAttack);
        poki.setSpecialAttack(poki.getSpecialAttack() + poki.listOfItems.get(0).specialAttack + poki.listOfItems.get(1).specialAttack
                                + poki.listOfItems.get(2).specialAttack);
        return poki;
    }

    static String[] getWinnerName2(StringBuilder output, List<PokemonInstance> pokemonsReadyToFight, int i, Arena arena) {
        String result = arena.executeFightStrategy(pokemonsReadyToFight.get(i), pokemonsReadyToFight.get(i + 3));
        output.append(result);
        output.append("\n");
        String[] lastLine = result.split("\n")[result.split("\n").length - 1].split(" ");
        return lastLine;
    }

    static String getWinnerName1(StringBuilder output, List<PokemonInstance> pokemonsReadyToFight, int i, Arena arena) {
        String s1 = arena.executeFightStrategy(pokemonsReadyToFight.get(i));
        output.append(s1);
        output.append("\n");
        return s1;
    }

    static void writeAntetInfos(StringBuilder output, List<PokemonInstance> pokemonsReadyToFight, int i, FightStrategy randomFight) {
        output.append("Pokemons " + randomFight.getClass().getName().substring(12));
        output.append("\n");
        output.append(pokemonsReadyToFight.get(i).getName() + " " + pokemonsReadyToFight.get(i + 3).getName());
        output.append("\n");
    }

    static void addBonusPointsForDuelWinner(List<PokemonInstance> pokemonsReadyToFight, List<Winner> winners, String[] lastLine) {
        for (PokemonInstance p : pokemonsReadyToFight) {
            if (lastLine[1].equals(p.getName())) {
                p.setHP(p.getHP() + 1);
                p.setDefense(p.getDefense() + 1);
                p.setSpecialAttack(p.getSpecialDefense() + 1);
                if (p.getNormalAttack() != 0) {
                    p.setNormalAttack(p.getNormalAttack() + 1);
                } else {
                    p.setSpecialAttack(p.getSpecialAttack() + 1);
                }
                // adaugam numele castigatorului in lista cu winneri pentru a decide ulterior care antrenor a fost cel mai bun
                // si marcam si faptul ca pokemonul apartine antrenorului 1 sau antrenorului 2
                int propertyOf = p.getPropertyOf();
                winners.add(new Winner(p, propertyOf));
            }
        }
    }

    static void addBonusPoints(List<PokemonInstance> pokemonsReadyToFight, String[] lastLine1) {
        for (PokemonInstance p : pokemonsReadyToFight) {
            if (lastLine1[1].equals(p.getName())) {
                p.setHP(p.getHP() + 1);
                p.setDefense(p.getDefense() + 1);
                p.setSpecialAttack(p.getSpecialDefense() + 1);
                if (p.getNormalAttack() != 0) {
                    p.setNormalAttack(p.getNormalAttack() + 1);
                } else {
                    p.setSpecialAttack(p.getSpecialAttack() + 1);
                }
            }
        }
    }

    static PokemonInstance validatePokemonWinner(Logger logger, StringBuilder output, List<Coach> coaches, List<Winner> winnersOfCoach2, PokemonInstance pokemonWinner2, int i2) {
        if (winnersOfCoach2.stream().count() >= 1) {
            pokemonWinner2 = winnersOfCoach2.get(0).getPokemon();
        } else {
            String nameOfTheWinnerCoach = coaches.get(i2).name;
            output.append("Coach " + nameOfTheWinnerCoach + " is the supreme winner of the Adventure!");
            output.append("\n");
            logger.info(String.valueOf(output), Main.arg);
        }
        return pokemonWinner2;
    }

    static PokemonInstance getPokemonWinner(PokemonInstance pokemonWinner2, boolean b, PokemonInstance pokemon, PokemonInstance pokemon2, PokemonInstance pokemon3, PokemonInstance pokemon4) {
        if (b) {
            pokemonWinner2 = getFinalWinner(pokemon,
                    pokemon2,
                    pokemonWinner2, pokemon3,
                    pokemon4);
        }
        return pokemonWinner2;
    }

    static PokemonInstance getFinalWinner(PokemonInstance pokemonWinner1,
                                          PokemonInstance pokemonWinner2,
                                          PokemonInstance finalWinner,
                                          PokemonInstance pokemonWinner12,
                                          PokemonInstance pokemonWinner22) {
        int sum1 = pokemonWinner1.getHP() +
                pokemonWinner1.getDefense() +
                pokemonWinner1.getSpecialDefense() +
                pokemonWinner1.getNormalAttack() +
                pokemonWinner1.getSpecialAttack();
        int sum2 = pokemonWinner2.getHP() +
                pokemonWinner2.getDefense() +
                pokemonWinner2.getSpecialDefense() +
                pokemonWinner2.getNormalAttack() +
                pokemonWinner2.getSpecialAttack();

        if (sum1 > sum2)
            finalWinner = pokemonWinner1;
        if (sum2 > sum1)
            finalWinner = pokemonWinner2;
        if (sum1 == sum2)
            if (pokemonWinner12.getName().compareTo(pokemonWinner22.getName()) < 0) {
                finalWinner = pokemonWinner1;
            } else {
                finalWinner = pokemonWinner2;
            }
        return finalWinner;
    }
}
