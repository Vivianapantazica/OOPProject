package com.company;

public interface Strategy {
    public String execute(PokemonInstance pokemon);
}
