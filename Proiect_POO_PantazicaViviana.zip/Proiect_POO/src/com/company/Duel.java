package com.company;

import java.util.Arrays;
import java.util.Random;

public class Duel implements FightStrategy {

    @Override
    public String fight(PokemonInstance[] pokemon1) {
        StringBuilder output = new StringBuilder();

        PokemonInstance pokemon = pokemon1[0];
        PokemonInstance enemy = pokemon1[1];
        int cd1Pokemon = pokemon.abilities[0].cd;
        int cd2Pokemon = pokemon.abilities[1].cd;
        int cd1Enemy = enemy.abilities[0].cd;
        int cd2Enemy = enemy.abilities[1].cd;
        int ok1Pokemon = 0;
        int ok2Pokemon = 0;
        int ok1Enemy = 0;
        int ok2Enemy = 0;
        int count = 0;

        while (pokemon.getHP() > 0 && enemy.getHP() > 0) {
            Strategy randomAttack1 = Arrays.asList(new ExecuteAbility1(), new ExecuteAbility2(), new ExecuteAttack()).get(new Random().nextInt(3));
            CoachCommand command1 = new CoachCommand(randomAttack1);
            Strategy randomAttack2 = Arrays.asList(new ExecuteAbility1(), new ExecuteAbility2(), new ExecuteAttack()).get(new Random().nextInt(3));
            CoachCommand command2 = new CoachCommand(randomAttack2);
            String[] fields1 = new String[10];
            String[] fields2 = new String[10];

            // Pentru primul Pokemon:
            // verificam daca abilitatea 1 este in cooldown sau nu, inainte de a putea fi executata
            if (randomAttack1.getClass().getName().equals("com.company.ExecuteAbility1")) {
                ok1Pokemon = 1;
                if (pokemon.abilities[0].cd == cd1Pokemon || pokemon.abilities[0].cd == 0) {
                    fields1 = command1.execute(pokemon).split(" ");
                } else {
                    randomAttack1 = new ExecuteAttack();
                    CoachCommand command1_reset = new CoachCommand(randomAttack1);
                    fields1 = command1_reset.execute(pokemon).split(" ");
                }
            }

            // verificam daca abilitatea 2 este in cooldown sau nu, inainte de a putea fi executata
            if (randomAttack1.getClass().getName().equals("com.company.ExecuteAbility2")) {
                ok2Pokemon = 1;
                if (pokemon.abilities[1].cd == cd2Pokemon || pokemon.abilities[1].cd == 0) {
                    fields1 = command1.execute(pokemon).split(" ");
                } else {
                    randomAttack1 = new ExecuteAttack();
                    CoachCommand command1_reset = new CoachCommand(randomAttack1);
                    fields1 = command1_reset.execute(pokemon).split(" ");
                }
            }

            // Pentru al doilea Pokemon:
            // verificam daca abilitatea 1 este in cooldown sau nu, inainte de a putea fi executata
            if (randomAttack2.getClass().getName().equals("com.company.ExecuteAbility1")) {
                ok1Enemy = 1;
                if (enemy.abilities[0].cd == cd1Enemy || enemy.abilities[0].cd == 0) {
                    fields2 = command2.execute(enemy).split(" ");
                } else {
                    randomAttack2 = new ExecuteAttack();
                    CoachCommand command2_reset = new CoachCommand(randomAttack2);
                    fields2 = command2_reset.execute(enemy).split(" ");
                }
            }

            // verificam daca abilitatea 2 este in cooldown sau nu, inainte de a putea fi executata
            if (randomAttack2.getClass().getName().equals("com.company.ExecuteAbility2")) {
                ok2Enemy = 1;
                if (enemy.abilities[1].cd == cd2Enemy || enemy.abilities[1].cd == 0) {
                    fields2 = command2.execute(enemy).split(" ");
                } else {
                    randomAttack2 = new ExecuteAttack();
                    CoachCommand command2_reset = new CoachCommand(randomAttack2);
                    fields2 = command2_reset.execute(enemy).split(" ");
                }
            }

            output.append(pokemon.getName() + randomAttack1.getClass().getName().substring(12) + " / " +
                    enemy.getName() + ": " + randomAttack2.getClass().getName().substring(12));
            output.append("\n");

            // Pokemon ataca enemy
            attack(output, pokemon, enemy, count, fields1, fields2, "HP: ");
            // Enemy ataca pokemon
            attack(output, enemy, pokemon, count, fields2, fields1, " HP: ");

            // descrestem la fiecare pas timpul reprezentat in campul cooldown
            // daca abilitatea a fost deja folosita (ok1 si ok2 verifica acest lucru)
            manageCoolDown(pokemon, cd1Pokemon, cd2Pokemon, ok1Pokemon, ok2Pokemon);
            manageCoolDown(enemy, cd1Enemy, cd2Enemy, ok1Enemy, ok2Enemy);

            // crestem numarul de iteratii pentru a reprezenta numarul de pasi ai bataliei
            count++;
        }

        if (pokemon.getHP() <= 0) {
            output.append("Pokemon " + enemy.getName() + " won!");
        } else {
            if (enemy.getHP() <= 0) {
                output.append("Pokemon " + pokemon.getName() + " won!");
            } else {
                output.append("Draw!");
            }
        }
        output.append("\n");
        return String.valueOf(output);
    }

    private void manageCoolDown(PokemonInstance pokemon, int cd1Pokemon, int cd2Pokemon, int ok1Pokemon, int ok2Pokemon) {
        // descrestem la fiecare pas timpul reprezentat in campul cooldown
        // daca abilitatea a fost deja folosita (ok1 si ok2 verifica acest lucru)
        if (ok1Pokemon == 1) {
            pokemon.abilities[0].cd--;
        }
        if (ok2Pokemon == 1) {
            pokemon.abilities[1].cd--;
        }

        // daca acesta atinge 0 sau o valoare negativa, atunci se reseteaza, iar abilitatea e gata de folosit din nou
        if (pokemon.abilities[0].cd < 0) {
            pokemon.abilities[0].cd = cd1Pokemon;
        } else {
            if (pokemon.abilities[1].cd < 0) {
                pokemon.abilities[1].cd = cd2Pokemon;
            }
        }
    }

    private void attack(StringBuilder output, PokemonInstance pokemon, PokemonInstance enemy, int count, String[] fields1, String[] fields2, String s) {
        // daca pokemonul nu este stuned de la pasul anterior
        if (pokemon.getIsStuned() == 0) {
            // si daca inamicul executa o abilitate
            if ("Ability1".equals(fields2[0]) || "Ability2".equals(fields2[0])) {
                // dar abilitatea respectiva nu are dodge
                if ("no".equals(fields2[6])) {
                    // verificam tipul de atac / abilitate pe care pokemonul o trimite
                    // si putem modifica fields-urile inamicului
                    // daca pokemonul trimite catre enemy un atac normal
                    if ("NormalAttack".equals(fields1[0])) {
                        enemy.setHP(enemy.getHP() - pokemon.getNormalAttack() + enemy.getDefense());
                    }
                    // daca pokemonul trimite catre enemy un atac special
                    if ("SpecialAttack".equals(fields1[0])) {
                        enemy.setHP(enemy.getHP() - pokemon.getSpecialAttack() + enemy.getSpecialDefense());
                    }
                    // daca pokemonul trimite catre enemy o abilitate
                    if ("Damage".equals(fields1[1])) {
                        enemy.setHP(enemy.getHP() - Integer.parseInt(fields1[2]));
                        // pokemonul isi imobilizeaza inamicul la urmatoarea miscare (foloseste abilitatea stun)
                        if ("yes".equals(fields1[4])) {
                            enemy.setIsStuned(1);
                        }
                    }
                }
            } else {
                // daca pokemonul trimite catre enemy un atac normal
                if ("NormalAttack".equals(fields1[0])) {
                    enemy.setHP(enemy.getHP() - pokemon.getNormalAttack() + enemy.getDefense());
                }
                // daca pokemonul trimite catre enemy un atac special
                if ("SpecialAttack".equals(fields1[0])) {
                    enemy.setHP(enemy.getHP() - pokemon.getSpecialAttack() + enemy.getSpecialDefense());
                }
                // daca pokemonul trimite catre enemy o abilitate
                if ("Damage".equals(fields1[1])) {
                    enemy.setHP(enemy.getHP() - Integer.parseInt(fields1[2]));
                    // pokemonul isi imobilizeaza inamicul la urmatoarea miscare (foloseste abilitatea stun)
                    if ("yes".equals(fields1[4])) {
                        enemy.setIsStuned(1);
                    }
                }
            }
            output.append("Step " + count + ": " + enemy.getName() + " HP: " + enemy.getHP() + " Ability1 Cooldown: "
                    + (enemy.abilities[0].cd + 1) + " Ability2 Cooldown: " + (enemy.abilities[1].cd + 1));
            output.append("\n");
        } else {
            if (pokemon.getIsStuned() == 1) {
                if ("NormalAttack".equals(fields2[0]) || "SpecialAttack".equals(fields2[0])) {
                    enemy.setHP(enemy.getHP() - pokemon.getNormalAttack() + enemy.getDefense());

                } else {
                    if ("no".equals(fields2[6])) {
                        enemy.setHP(enemy.getHP() - pokemon.getNormalAttack() + enemy.getDefense());
                    }
                }
                pokemon.setIsStuned(2);
                output.append("Step " + count + ": " + enemy.getName() + s + enemy.getHP() + " is stuned for the next move.");
                output.append("\n");
            } else {
                pokemon.setIsStuned(0);
                output.append("Step " + count + ": " + enemy.getName() + " HP: " + enemy.getHP() + " ");
                output.append("\n");
            }
        }
    }
}
