package com.company;

import java.util.Arrays;
import java.util.Random;

public class ExecuteAbility2 implements Strategy{
    String s1, s2 = " Stuned no ", s3 = "Dodge no";
    @Override
    public String execute(PokemonInstance pokemon) {
            if (pokemon.abilities[1].dmg != 0) {
                s1 = "Damage " + pokemon.abilities[1].dmg;
            }
            if (pokemon.abilities[1].stun != false) {
                s2 = " Stuned yes ";
            }
            if (pokemon.abilities[1].dodge != false) {
                s3 = "Dodge yes";
            }
            return "Ability2 " + s1 + s2 + s3 + " Cooldown " + pokemon.abilities[1].cd;
    }
}
