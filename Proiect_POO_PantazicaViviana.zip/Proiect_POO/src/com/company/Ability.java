package com.company;

public class Ability {
    String pokemonsName;
    int dmg; //Damage
    boolean stun;
    boolean dodge;
    int cd; //cooldown

    public Ability(String pokemonsName, int dmg, boolean stun, boolean dodge, int cd) {
        this.pokemonsName = pokemonsName;
        this.dmg = dmg;
        this.stun = stun;
        this.dodge = dodge;
        this.cd = cd;
    }
}
