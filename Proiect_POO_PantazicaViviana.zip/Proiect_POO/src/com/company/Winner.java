package com.company;

public class Winner {
    private PokemonInstance pokemon;
    private int belongsToCoach;

    public Winner(PokemonInstance pokemon, int belongsToCoach) {
        this.pokemon = pokemon;
        this.belongsToCoach = belongsToCoach;
    }

    public void setPokemon(PokemonInstance pokemon) {
        this.pokemon = pokemon;
    }

    public void setBelongsToCoach(int belongsToCoach) {
        this.belongsToCoach = belongsToCoach;
    }

    public PokemonInstance getPokemon() {
        return pokemon;
    }

    public int getBelongsToCoach() {
        return belongsToCoach;
    }
}
