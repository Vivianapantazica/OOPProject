package com.company;

import java.util.Collections;

public class CoachCommand implements Strategy{
    private Strategy action;

    public CoachCommand(Strategy action){
        this.action = action;
    }
    @Override
    public String execute(PokemonInstance pokemon) {
        return action.execute(pokemon);
    }
}
