package com.company;

public class PokemonFactory {
    private static PokemonFactory pokemonFactory;

    public static enum PokemonType {
        Neutrel1,
        Neutrel2,
        Pikachu,
        Bulbasaur,
        Charmander,
        Squirlte,
        Snorlax,
        Vulpix,
        Eevee,
        Jigglypuff,
        Meowth,
        Psyduck
    }

    public PokemonInstance createPokemon(PokemonType p) {
        switch (p) {           //Name HP NormalAttack SpecialAttack Defense SpecialDefense
            case Neutrel1:
                return new Neutrel("Neutrel1", 10, 3, 1, 1);
            case Neutrel2:
                return new Neutrel("Neutrel2", 20, 4, 1, 1);
            case Pikachu:
                return new Pokemon.PokemonBuilder("Pikachu", 35, 2, 3).withSpecialAttack(4).build();
            case Bulbasaur:
                return new Pokemon.PokemonBuilder("Bulbasaur", 42, 3, 1).withSpecialAttack(5).build();
            case Charmander:
                return new Pokemon.PokemonBuilder("Charmander", 50, 3, 2).withNormalAttack(4).build();
            case Squirlte:
                return new Pokemon.PokemonBuilder("Squirlte", 60, 5, 5).withSpecialAttack(3).build();
            case Snorlax:
                return new Pokemon.PokemonBuilder("Snorlax", 62, 6, 4).withNormalAttack(3).build();
            case Vulpix:
                return new Pokemon.PokemonBuilder("Vulpix", 36, 2, 4).withNormalAttack(5).build();
            case Eevee:
                return new Pokemon.PokemonBuilder("Eevee", 39, 3, 3).withSpecialAttack(4).build();
            case Jigglypuff:
                return new Pokemon.PokemonBuilder("Jigglypuff", 34, 2, 3).withNormalAttack(4).build();
            case Meowth:
                return new Pokemon.PokemonBuilder("Meowth", 41, 4, 2).withNormalAttack(3).build();
            case Psyduck:
                return new Pokemon.PokemonBuilder("Psyduck", 43, 3, 3).withNormalAttack(3).build();
        }
        throw new IllegalArgumentException("Pokemon type " + p + " was not found.");
    }

    public static PokemonFactory createSingleFactory() {
        if (pokemonFactory == null)
            pokemonFactory = new PokemonFactory();
        return pokemonFactory;
    }
}
