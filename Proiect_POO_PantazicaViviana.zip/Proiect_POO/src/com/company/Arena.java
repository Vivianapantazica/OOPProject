package com.company;
public class Arena {
    private FightStrategy fightStrategy;

    public Arena(FightStrategy fightStrategy) { this.fightStrategy = fightStrategy; }

    public String executeFightStrategy(PokemonInstance ... pokemon){
        return fightStrategy.fight(pokemon);
    }
}
