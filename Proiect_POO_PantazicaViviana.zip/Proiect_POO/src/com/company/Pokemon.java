package com.company;

import com.company.Ability;

import java.util.ArrayList;
import java.util.List;

public class Pokemon extends PokemonInstance{

    private String name;                                //required
    private int HP;                                     //required
    private int normalAttack;                           //optional
    private int specialAttack;                          //optional
    private int defense;                                //required
    private int specialDefense;                         //required
    Ability[] abilities = new Ability[2];
    List<Item> listOfItems = new ArrayList<>();

    public Pokemon(String name, int HP, int normalAttack, int specialAttack, int defense, int specialDefense) {
        this.name = name;
        this.HP = HP;
        this.normalAttack = normalAttack;
        this.specialAttack = specialAttack;
        this.defense = defense;
        this.specialDefense = specialDefense;
    }

    private Pokemon(PokemonBuilder builder) {
        this.name = builder.name;
        this.HP = builder.HP;
        this.defense = builder.defense;
        this.specialDefense = builder.specialDefense;
        this.normalAttack = builder.normalAttack;
        this.specialAttack = builder.specialAttack;
    }

    public String getName() {
        return name;
    }

    public int getHP() {
        return HP;
    }

    public int getNormalAttack() {
        return normalAttack;
    }

    public int getSpecialAttack() {
        return specialAttack;
    }

    public int getDefense() {
        return defense;
    }

    public int getSpecialDefense() {
        return specialDefense;
    }

    public Ability[] getAbilities() {
        return abilities;
    }

    public List<Item> getListOfItems() {
        return listOfItems;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setHP(int HP) {
        this.HP = HP;
    }

    public void setNormalAttack(int normalAttack) {
        this.normalAttack = normalAttack;
    }

    public void setSpecialAttack(int specialAttack) {
        this.specialAttack = specialAttack;
    }

    public void setDefense(int defense) {
        this.defense = defense;
    }

    public void setSpecialDefense(int specialDefense) {
        this.specialDefense = specialDefense;
    }

    public void setAbilities(Ability[] abilities) {
        this.abilities = abilities;
    }

    public void setListOfItems(List<Item> listOfItems) {
        this.listOfItems = listOfItems;
    }

    @Override
    public String toString() {
        return null;
    }

    public static class PokemonBuilder {
        private String name;                                //required
        private int HP;                                     //required
        private int normalAttack;                           //optional
        private int specialAttack;                          //optional
        private int defense;                                //required
        private int specialDefense;                         //required

        public PokemonBuilder(String name, int HP, int normalDefense, int specialDefense){
            this.name = name;
            this.HP = HP;
            this.defense = normalDefense;
            this.specialDefense = specialDefense;
        }

        public PokemonBuilder withNormalAttack(int normalAttack){
            this.normalAttack = normalAttack;
            return this;
        }

        public PokemonBuilder withSpecialAttack(int specialAttack){
            this.specialAttack = specialAttack;
            return this;
        }
        public Pokemon build(){
            return new Pokemon(this);
        }
    }
}
