package com.company;

import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import static com.company.Administration.addBonusPoints;
import static com.company.Administration.getPokemonWinner;

public class Main {
    static int arg;
    private static int yesterday = 5;
    int tomorrow = 15;
    public static void main(String[] args) {
        int today =10, tomorrow = 20;
        System.out.println(today + tomorrow + Main.yesterday);


        Logger logger = new Logger("MyLogger");

        Administration adm = new Administration();
        StringBuilder output = new StringBuilder();

        /* Scriem in linia de comanda 1 - pentru varianta in care dorim toate informatiile scrise
         intr-un fisier sau 2 - pentru ca informatiile sa fie afisate la consola */

        arg = (new java.util.Scanner(System.in).nextInt());

        /* Am creat, folosind SingletonPattern, o singura instanta de PokemonFactory */
        PokemonFactory factory = PokemonFactory.createSingleFactory();

        /* Cream folosind Factory Method o lista de pokemoni */
        List<PokemonInstance> pokemons = new ArrayList<>(List.of(
                factory.createPokemon(PokemonFactory.PokemonType.Neutrel1),
                factory.createPokemon(PokemonFactory.PokemonType.Neutrel2),
                factory.createPokemon(PokemonFactory.PokemonType.Pikachu),
                factory.createPokemon(PokemonFactory.PokemonType.Bulbasaur),
                factory.createPokemon(PokemonFactory.PokemonType.Charmander),
                factory.createPokemon(PokemonFactory.PokemonType.Squirlte),
                factory.createPokemon(PokemonFactory.PokemonType.Snorlax),
                factory.createPokemon(PokemonFactory.PokemonType.Vulpix),
                factory.createPokemon(PokemonFactory.PokemonType.Eevee),
                factory.createPokemon(PokemonFactory.PokemonType.Jigglypuff),
                factory.createPokemon(PokemonFactory.PokemonType.Meowth),
                factory.createPokemon(PokemonFactory.PokemonType.Pikachu),
                factory.createPokemon(PokemonFactory.PokemonType.Psyduck)));

        /* Initializam pokemonii cu abilitatile lor speciale */
        List<Ability> abs1 = adm.initAbility1(".\\init\\ability1");
        List<Ability> abs2 = adm.initAbility2(".\\init\\ability2");
        adm.initPokemonsWithBothAbilities(pokemons, abs1, abs2);
        List<Item> listOfItems = adm.createListOfItems(".\\init\\items");

        /* Cream lista cu cei doi antrenori care se vor confrunta si adaugam pokemonilor lista cu itemi magici */
        //List<Coach> coaches = adm.initCoaches(".\\tests\\test3", pokemons, listOfItems);
        //List<Coach> coaches = adm.initCoaches(".\\tests\\test1", pokemons, listOfItems);
        //List<Coach> coaches = adm.initCoaches(".\\tests\\test2", pokemons, listOfItems);
        //List<Coach> coaches = adm.initCoaches(".\\tests\\test4", pokemons, listOfItems);
        List<Coach> coaches = adm.initCoaches(".\\tests\\test5", pokemons, listOfItems);
        //List<Coach> coaches = adm.initCoaches(".\\tests\\test6", pokemons, listOfItems);
        //List<Coach> coaches = adm.initCoaches(".\\tests\\test7", pokemons, listOfItems);
        //List<Coach> coaches = adm.initCoaches(".\\tests\\test8", pokemons, listOfItems);
        //List<Coach> coaches = adm.initCoaches(".\\tests\\test9", pokemons, listOfItems);
        //List<Coach> coaches = adm.initCoaches(".\\tests\\test10", pokemons, listOfItems);

        /* Setam campurile propertyOf asa incat sa apartina fiecare pokemon antrenorului sau */
        distributePokemons(coaches);

        /* Fiecare pokemon va lupta utilizand itemii din lista lor, pe rand */
        List<PokemonInstance> pokemonsReadyToFight = getPokemonsReadyToFight(adm, coaches);

        /* START */

        startAdventure(logger, output, coaches, pokemonsReadyToFight);
        logger.info(String.valueOf(output), arg);
    }

    private static void distributePokemons(List<Coach> coaches) {
        coaches.get(0).pokemons.get(0).setPropertyOf(1);
        coaches.get(0).pokemons.get(1).setPropertyOf(1);
        coaches.get(0).pokemons.get(2).setPropertyOf(1);
        coaches.get(1).pokemons.get(0).setPropertyOf(2);
        coaches.get(1).pokemons.get(1).setPropertyOf(2);
        coaches.get(1).pokemons.get(2).setPropertyOf(2);
    }

    private static List<PokemonInstance> getPokemonsReadyToFight(Administration adm, List<Coach> coaches) {
        List<PokemonInstance> pokemonsReadyToFight = new ArrayList<>();
        pokemonsReadyToFight.add(adm.getPowersFromMagicalItems(coaches.get(0).pokemons.get(0)));
        pokemonsReadyToFight.add(adm.getPowersFromMagicalItems(coaches.get(0).pokemons.get(1)));
        pokemonsReadyToFight.add(adm.getPowersFromMagicalItems(coaches.get(0).pokemons.get(2)));
        pokemonsReadyToFight.add(adm.getPowersFromMagicalItems(coaches.get(1).pokemons.get(0)));
        pokemonsReadyToFight.add(adm.getPowersFromMagicalItems(coaches.get(1).pokemons.get(1)));
        pokemonsReadyToFight.add(adm.getPowersFromMagicalItems(coaches.get(1).pokemons.get(2)));
        return pokemonsReadyToFight;
    }

    private static void startAdventure(Logger logger, StringBuilder output, List<Coach> coaches, List<PokemonInstance> pokemonsReadyToFight) {
        List<Winner> winners = new ArrayList<>();
        int i;
        for (i = 0; i < 3; i++) {
            FightStrategy randomFight = Arrays.asList(new FightNeutrel1(), new FightNeutrel2(), new Duel()).get(new Random().nextInt(3));
            Arena arena = new Arena(randomFight);
            while (!randomFight.getClass().getName().substring(12).equals("Duel")) {

                Administration.writeAntetInfos(output, pokemonsReadyToFight, i, randomFight);

                /* Cat timp lupta aleasa aleator de Arena nu este un duel, pokemonii se pot
                 confrunta cu neutrelii, obtinand bonusuri din castiguri la toate field-urile semnificative */
                ThreadForFightWithNeutrel f1 = new ThreadForFightWithNeutrel(output,pokemonsReadyToFight, i, arena, logger, arg);
                ThreadForFightWithNeutrel f2 = new ThreadForFightWithNeutrel(output,pokemonsReadyToFight, i+3, arena, logger, arg);

                /* Folosim thread-uri pentru desfasurarea simultana a luptelor cu neutreli */
                ExecutorService executor = Executors.newFixedThreadPool(2);
                executor.execute(f1);
                executor.execute(f2);

                executor.shutdown();
                try{
                    executor.awaitTermination(5, TimeUnit.SECONDS);
                } catch (InterruptedException e){
                    e.printStackTrace();
                }

                /* Avem nevoie de ultima linie din output-ul rezultat in urma executiei bataliei pentru a extrage numele castigatorului*/
                String[] lastLine1 = f1.getLastLine();
                String[] lastLine2 = f2.getLastLine();

                /* Se adauga bonusurile pentru castigatorul confruntarii desfasurate pe primul thread */
                addBonusPoints(pokemonsReadyToFight, lastLine1);

                /* Se adauga bonusurile pentru castigatorul confruntarii desfasurate pe al doilea thread */
                addBonusPoints(pokemonsReadyToFight, lastLine2);

                /* Se continua batalia pana ce randomFight va fi un duel */
                randomFight = Arrays.asList(new FightNeutrel1(), new FightNeutrel2(), new Duel()).get(new Random().nextInt(3));
            }
            /* RandomFight este un duel si, in urma acestuia, se pune capat unei runde */
            Administration.writeAntetInfos(output, pokemonsReadyToFight, i, randomFight);

            String[] lastLine = Administration.getWinnerName2(output, pokemonsReadyToFight, i, arena);

            Administration.addBonusPointsForDuelWinner(pokemonsReadyToFight, winners, lastLine);
        }

        output.append("The winners are:\n");
        for( Winner w : winners){
            output.append(w.getPokemon().getName() + " " + w.getPokemon().getHP() + " " + w.getPokemon().getDefense()
                    + " " + w.getPokemon().getSpecialDefense() + " " + w.getBelongsToCoach() + "\n");
        }

        /* Pentru duelul final, avem nevoie de lista de castigatori */

        List<Winner> winnersOfCoach1 = winners.stream().filter(w -> w.getBelongsToCoach() == 1).collect(Collectors.toList());
        List<Winner> winnersOfCoach2 = winners.stream().filter(w -> w.getBelongsToCoach() == 2).collect(Collectors.toList());

        PokemonInstance pokemonWinner1 = null;
        PokemonInstance pokemonWinner2 = null;

        // Tratam intai cazurile in care un antrenor a dominat toate bataliile

        pokemonWinner1 = Administration.validatePokemonWinner(logger, output, coaches, winnersOfCoach1, pokemonWinner1, 1);

        pokemonWinner2 = Administration.validatePokemonWinner(logger, output, coaches, winnersOfCoach2, pokemonWinner2, 0);

        // Tratam cazurile in care un antrenor are mai mult decat un invingator
        if(winnersOfCoach1.size() > 1 && winnersOfCoach2.size() > 1 ) {
            pokemonWinner1 = getPokemonWinner(pokemonWinner1, winnersOfCoach1.stream().count() == 2,
                    winnersOfCoach1.get(0).getPokemon(), winnersOfCoach1.get(1).getPokemon(),
                    winnersOfCoach1.get(0).getPokemon(), winnersOfCoach1.get(1).getPokemon());
        }

        if(winnersOfCoach1.size() > 1 && winnersOfCoach2.size() > 1 ) {
            pokemonWinner2 = getPokemonWinner(pokemonWinner2, winnersOfCoach2.stream().count() == 2,
                    winnersOfCoach2.get(0).getPokemon(), winnersOfCoach2.get(1).getPokemon(),
                    winnersOfCoach1.get(0).getPokemon(), winnersOfCoach1.get(1).getPokemon());
        }

        /* Acum duelul final intre pokemonWinner1 si pokemonWinner2 poate sa inceapa! */

        PokemonInstance finalWinner = null; // default

        finalWinner = getPokemonWinner(finalWinner, pokemonWinner1 != null && pokemonWinner2 != null,
                pokemonWinner1, pokemonWinner2, pokemonWinner1, pokemonWinner2);

        output.append("\n");
        if(finalWinner != null) {
            String nameOfTheWinnerCoach = coaches.get(finalWinner.getPropertyOf() - 1).name;
            output.append("The supreme winner is: " + nameOfTheWinnerCoach + "!");
        }
    }
}