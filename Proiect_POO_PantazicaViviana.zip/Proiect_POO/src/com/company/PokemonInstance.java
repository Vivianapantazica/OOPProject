package com.company;

import java.util.ArrayList;
import java.util.List;

abstract class PokemonInstance {
    private String name;                                //required
    private int HP;                                     //required
    private int normalAttack;                           //optional
    private int specialAttack;                          //optional
    private int defense;                                //required
    private int specialDefense;                         //required
    private int isStuned = 0;
    private int propertyOf;

    Ability[] abilities = new Ability[2];
    List<Item> listOfItems = new ArrayList<>();

    public abstract String toString();

    public String getName() {
        return name;
    }

    public int getHP() {
        return HP;
    }

    public int getNormalAttack() {
        return normalAttack;
    }

    public int getSpecialAttack() {
        return specialAttack;
    }

    public int getDefense() {
        return defense;
    }

    public int getSpecialDefense() {
        return specialDefense;
    }

    public Ability[] getAbilities() {
        return abilities;
    }

    public List<Item> getListOfItems() {
        return listOfItems;
    }

    public int getPropertyOf() {
        return propertyOf;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setHP(int HP) {
        this.HP = HP;
    }

    public void setNormalAttack(int normalAttack) {
        this.normalAttack = normalAttack;
    }

    public void setSpecialAttack(int specialAttack) {
        this.specialAttack = specialAttack;
    }

    public void setDefense(int defense) {
        this.defense = defense;
    }

    public void setSpecialDefense(int specialDefense) {
        this.specialDefense = specialDefense;
    }

    public void setAbilities(Ability[] abilities) {
        this.abilities = abilities;
    }

    public void setListOfItems(List<Item> listOfItems) {
        this.listOfItems = listOfItems;
    }

    public void setPropertyOf(int propertyOf) {
        this.propertyOf = propertyOf;
    }

    public int getIsStuned() {
        return isStuned;
    }

    public void setIsStuned(int isStuned) {
        this.isStuned = isStuned;
    }
}
