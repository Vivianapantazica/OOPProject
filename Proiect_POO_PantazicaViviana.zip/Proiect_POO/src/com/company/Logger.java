package com.company;

import java.io.BufferedWriter;
import java.io.FileWriter;

public class Logger {
    String name;
    public Logger(String name) {
        this.name = name;
    }

    public void info(String data, int i){
        if(i == 1) {
            try {
                // Creates a FileWriter
                FileWriter file = new FileWriter("C:\\Users\\Hp\\Desktop\\Proiect_POO\\output_info\\output.txt");

                // Creates a BufferedWriter
                BufferedWriter output = new BufferedWriter(file);

                // Writes the string to the file
                output.write(data);

                // Closes the writer
                output.close();
            } catch (Exception e) {
                e.getStackTrace();
            }
        } else {
            System.out.println(data);
        }
    }
}
