package com.company;

import java.util.List;

public class Coach {
    List<PokemonInstance> pokemons;
    int age;
    String name;
    public Coach(List<PokemonInstance> pokemons, int age, String name) {
        this.pokemons = pokemons;
        this.age = age;
        this.name = name;
    }
}
