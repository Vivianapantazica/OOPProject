package com.company;

import java.util.List;

public class ThreadForFightWithNeutrel implements Runnable{
    StringBuilder output;
    List<PokemonInstance> pokemonsReadyToFight;
    Arena arena;
    int i;
    String winner;
    Logger logger;
    int value;

    public ThreadForFightWithNeutrel(StringBuilder output, List<PokemonInstance> pokemonsReadyToFight, int i, Arena arena, Logger logger, int value) {
        this.output = output;
        this.pokemonsReadyToFight = pokemonsReadyToFight;
        this.arena = arena;
        this.i = i;
        this.logger = logger;
        this.value = value;
    }

    @Override
    public void run() {
        winner = Administration.getWinnerName1(output, pokemonsReadyToFight, i, arena);
        logger.info(winner, value);
    }

    public String[] getLastLine() {
        return winner.split("\n")[winner.split("\n").length - 1].split(" ");
    }
}
