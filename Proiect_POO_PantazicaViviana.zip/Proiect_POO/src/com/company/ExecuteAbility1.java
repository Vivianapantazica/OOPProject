package com.company;

import java.util.Arrays;
import java.util.Random;

public class ExecuteAbility1 implements Strategy{
    String s1, s2 = " Stuned no ", s3 = "Dodge no";
    @Override
    public String execute(PokemonInstance pokemon) {
            if (pokemon.abilities[0].dmg != 0) {
                s1 = "Damage " + pokemon.abilities[0].dmg;
            }
            if (pokemon.abilities[0].stun != false) {
                s2 = " Stuned yes ";
            }
            if (pokemon.abilities[0].dodge != false) {
                s3 = "Dodge yes";
            }
            return "Ability1 " + s1 + s2 + s3 + " Cooldown " + pokemon.abilities[0].cd;
    }
}
