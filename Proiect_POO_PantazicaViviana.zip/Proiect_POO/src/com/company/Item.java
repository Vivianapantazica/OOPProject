package com.company;

public class Item {
    String name;
    int HP;
    int normalAttack;
    int specialAttack;
    int defense;
    int specialDefense;
    Ability[] abilities = new Ability[2];

    public Item(String name, int HP, int normalAttack, int specialAttack, int defense, int specialDefense) {
        this.name = name;
        this.HP = HP;
        this.normalAttack = normalAttack;
        this.specialAttack = specialAttack;
        this.defense = defense;
        this.specialDefense = specialDefense;
    }
}
