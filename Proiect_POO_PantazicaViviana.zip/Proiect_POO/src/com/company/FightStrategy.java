package com.company;

public interface FightStrategy {
    public String fight(PokemonInstance[] pokemon);
}
