package com.company;

import java.util.Arrays;
import java.util.Random;

public class FightNeutrel1 implements FightStrategy{
    @Override
    public String fight(PokemonInstance[] pokemon1) {
        StringBuilder output = new StringBuilder();
        int count = 0;
        PokemonInstance enemy = new Neutrel("Neutrel1", 10, 3, 1, 1);

        PokemonInstance pokemon = pokemon1[0];

        int cd1Pokemon = pokemon.abilities[0].cd;
        int cd2Pokemon = pokemon.abilities[1].cd;
        int ok1 = 0;
        int ok2 = 0;

        while (pokemon.getHP() > 0 && enemy.getHP() > 0) {
            Strategy randomAttack1 = Arrays.asList(new ExecuteAbility1(), new ExecuteAbility2(), new ExecuteAttack()).get(new Random().nextInt(3));
            CoachCommand command1 = new CoachCommand(randomAttack1);
            Strategy randomAttack2 = new ExecuteAttack();
            CoachCommand command2 = new CoachCommand(randomAttack2);
            String[] fields1 = new String[10];

            // daca trebuie executat un atac simplu/ special, acesta nu este conditionat
            if (randomAttack1.getClass().getName().equals("com.company.ExecuteAttack")) {
                fields1 = command1.execute(pokemon).split(" ");
            }

            // verificam daca abilitatea 1 este in cooldown sau nu, inainte de a putea fi executata
            if (randomAttack1.getClass().getName().equals("com.company.ExecuteAbility1")) {
                ok1 = 1;
                if (pokemon.abilities[0].cd == cd1Pokemon || pokemon.abilities[0].cd == 0) {
                    fields1 = command1.execute(pokemon).split(" ");
                } else {
                    randomAttack1 = new ExecuteAttack();
                    CoachCommand command1_reset = new CoachCommand(randomAttack1);
                    fields1 = command1_reset.execute(pokemon).split(" ");
                }
            }

            // verificam daca abilitatea 2 este in cooldown sau nu, inainte de a putea fi executata
            if (randomAttack1.getClass().getName().equals("com.company.ExecuteAbility2") ) {
                ok2 = 1;
                if (pokemon.abilities[1].cd == cd2Pokemon || pokemon.abilities[1].cd == 0) {
                    fields1 = command1.execute(pokemon).split(" ");
                } else {
                    randomAttack1 = new ExecuteAttack();
                    CoachCommand command1_reset = new CoachCommand(randomAttack1);
                    fields1 = command1_reset.execute(pokemon).split(" ");
                }
            }

            output.append("Neutrel1: " + randomAttack2.getClass().getName().substring(12) + " / " +
                    pokemon.getName() + ": " + randomAttack1.getClass().getName().substring(12));
            output.append("\n");

            // stim ca Neutrel1 poate avea doar AtacNormal, dar tot trebuie sa verificam daca nu cumva a fost stuned
            // la pasul anterior:

            String[] fields2 = command2.execute(enemy).split(" ");

            getTypeOfAttack(enemy, pokemon, fields1);

            // descrestem la fiecare pas timpul reprezentat in campul cooldown
            // daca abilitatea a fost deja folosita (ok1 si ok2 verifica acest lucru)
            manageCoolDown(pokemon, cd1Pokemon, cd2Pokemon, ok1, ok2);

            // daca enemy nu este stuned si trimite catre pokemon un atac normal, iar pokemonul nu are abilitate cu "dodge"
            attackPokemon(output, count, enemy, pokemon, fields1);

            output.append("Step " + count + ": " + pokemon.getName() + " HP: " + pokemon.getHP() + " Ability1 Cooldown: "
                    + pokemon.abilities[0].cd + " Ability2 Cooldown: " + pokemon.abilities[1].cd);
            output.append("\n");

            // crestem numarul de iteratii pentru a reprezenta numarul de pasi ai bataliei
            count++;
        }

        if(pokemon.getHP() == 0) {
            output.append("Neutrel1 won!");
        } else {
            output.append("Pokemon " + pokemon.getName() + " won!");
        }
        output.append("\n");
        return String.valueOf(output);
    }

    private void attackPokemon(StringBuilder output, int count, PokemonInstance enemy, PokemonInstance pokemon, String[] fields1) {
        if(enemy.getIsStuned() == 0) {
            if ("NormalAttack".equals(fields1[0]) || "SpecialAttack".equals(fields1[0])) {
                pokemon.setHP(pokemon.getHP() - enemy.getNormalAttack() + pokemon.getDefense());

            } else {
                if ("no".equals(fields1[6])) {
                    pokemon.setHP(pokemon.getHP() - enemy.getNormalAttack() + pokemon.getDefense());
                }
            }
            output.append("Step " + count + ": " + enemy.getName() + " HP: " + enemy.getHP() + " ");
            output.append("\n");
        } else {
            if(enemy.getIsStuned() == 1) {
                if ("NormalAttack".equals(fields1[0]) || "SpecialAttack".equals(fields1[0])) {
                    pokemon.setHP(pokemon.getHP() - enemy.getNormalAttack() + pokemon.getDefense());

                } else {
                    if ("no".equals(fields1[6])) {
                        pokemon.setHP(pokemon.getHP() - enemy.getNormalAttack() + pokemon.getDefense());
                    }
                }
                enemy.setIsStuned(2);
                output.append("Step " + count + ": " + enemy.getName() + "HP: " + enemy.getHP() + " is stuned for the next move.");
                output.append("\n");
            } else {
                enemy.setIsStuned(0);
                output.append("Step " + count + ": " + enemy.getName() + " HP: " + enemy.getHP() + " ");
                output.append("\n");
            }
        }
    }

    private void manageCoolDown(PokemonInstance pokemon, int cd1Pokemon, int cd2Pokemon, int ok1, int ok2) {
        if(ok1 == 1){
            pokemon.abilities[0].cd--;
        }
        if(ok2 == 1){
            pokemon.abilities[1].cd--;
        }

        // daca acesta atinge 0 sau o valoare negativa, atunci se reseteaza, iar abilitatea e gata de folosit din nou
        if (pokemon.abilities[0].cd < 0) {
            pokemon.abilities[0].cd = cd1Pokemon;
        } else {
            if (pokemon.abilities[1].cd < 0) {
                pokemon.abilities[1].cd = cd2Pokemon;
            }
        }
    }

    private void getTypeOfAttack(PokemonInstance enemy, PokemonInstance pokemon, String[] fields1) {
        // daca pokemonul trimite catre enemy un atac normal
        if ("NormalAttack".equals(fields1[0])) {
            enemy.setHP(enemy.getHP() - pokemon.getNormalAttack() + enemy.getDefense());
        }
        // daca pokemonul trimite catre enemy un atac special
        if ("SpecialAttack".equals(fields1[0])) {
            enemy.setHP(enemy.getHP() - pokemon.getSpecialAttack() + enemy.getSpecialDefense());
        }
        // daca pokemonul trimite catre enemy o abilitate
        if ("Damage".equals(fields1[1])) {
            enemy.setHP(enemy.getHP() - Integer.parseInt(fields1[2]));
            // pokemonul isi imobilizeaza inamicul la urmatoarea miscare (foloseste abilitatea stun)
            if("yes".equals(fields1[4])){
                enemy.setIsStuned(1);
            }
        }
    }
}


